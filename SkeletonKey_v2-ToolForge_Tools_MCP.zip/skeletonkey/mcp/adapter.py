"""Registry -> MCP server bridge (low-level Server, dynamic tools/list).

Why low-level instead of MCPServer's `@tool` decorator:
  * `tools/list` must be computed per session from the live CapabilityProfile
    (gating + provider de-dup + token budget), not fixed at import time;
  * `inputSchema` comes from ToolManifest, so a python signature refactor can
    never silently change the public contract of a tool;
  * we can raise `notifications/tools/list_changed` when a re-probe changes the
    advertised set (e.g. someone installs `rg`).

Handlers follow mcp 2.x: `async def h(ctx, params) -> ResultModel`.
"""

from __future__ import annotations

import asyncio
import os
import time
from contextlib import asynccontextmanager, suppress
from typing import Any

from ..core.engine import ApprovalRequired, CallContext
from ..core.errors import E, SkeletonKeyError
from ..core.util import compact_json
from ..version import __version__

SERVER_TITLE = "SkeletonKey ToolForge"

INSTRUCTIONS = """Adaptive filesystem + multi-shell toolkit for autonomous agents.

How to use this server well:
- The advertised set is capability-gated for THIS host. If something is missing, no
  backend exists for it here; `registry.search` with include_gated=true shows what is
  gated and why.
- Discovery: `registry.route {task}` ranks tools for a need (exact-name first, then a
  deterministic lexical stage, each hit carrying its `reasons`); `registry.expand
  {tier}` switches the advertised set between `core` (bootstrap), `task` and `full`
  (default) - the set changes, and a `tools/list_changed` notification follows.
  `capabilities.explain {capability}` says why a capability is gated here, with the
  provider receipt.
- Prefer `fs.patch` over `fs.write` when editing an existing file: it returns a unified
  diff, refuses stale writes (expect_sha), and yields an undo_token.
- `shell.run` executes your script verbatim. `data.completed=false` means the script
  never reached its last line, so treat that run as partial - not as a clean failure.
- Pick `dialect` from `shell.available` rather than assuming bash on Windows or pwsh on CI.
- Failures return error.code, error.hint and often next_actions. Follow the hint; do not
  retry an identical call.
- Paths are sandboxed to declared roots. SANDBOX_VIOLATION is a policy answer, not a
  transient error - do not retry it.
"""


class McpBridge:
    """Holds the adapter state; one per server, many client sessions.

    `--transport streamable-http` serves several clients from one bridge, so
    notification bookkeeping is per-connection: `sessions` holds every client
    we have served, and `_digest` is the advertisement they were last told
    about. A single shared digest would let the first client notified advance
    it and silently starve the rest, which is the bug this structure exists to
    prevent (see tests/test_mcp_multisession.py).
    """

    def __init__(self, toolkit: Any) -> None:
        self.toolkit = toolkit
        self.engine = toolkit.engine
        # every client currently connected. Notifications go to all of them:
        # a toolset change is not private to whoever triggered it.
        self.sessions: list[Any] = []
        # the session we last served a request on; kept for callers that still
        # reach for a single session (and for stdio, where there is only one)
        self.session: Any = None
        self.ctx = CallContext.from_config(toolkit.config, session_id=f"mcp-{os.getpid()}")
        self._name_map: dict[str, str] = {}
        self._digest: str | None = None

    # ----------------------------------------------------------------- sessions
    def track_session(self, session: Any) -> None:
        """Remember a client so it can be notified of toolset changes.

        Idempotent: `on_list_tools` runs on every tools/list, and a client that
        polls would otherwise stack up duplicates and get N notifications.
        Identity comparison, not equality - session objects are not hashable
        in every mcp version, and two distinct clients must never collapse.
        """
        if session is None:
            return
        if not any(s is session for s in self.sessions):
            self.sessions.append(session)
        self.session = session

    def drop_session(self, session: Any) -> None:
        self.sessions = [s for s in self.sessions if s is not session]
        if self.session is session:
            self.session = self.sessions[-1] if self.sessions else None

    # ------------------------------------------------------------------- naming
    def names(self) -> dict[str, str]:
        """mcp name -> tool id. Dots are legal in MCP names, so we keep them."""
        mapping = {}
        for man in self.engine.registry.all():
            mapping[man.id] = man.id
            mapping[man.mcp_name] = man.id
        self._name_map = mapping
        return mapping

    def resolve_name(self, name: str) -> str:
        if not self._name_map:
            self.names()
        if name in self._name_map:
            return self._name_map[name]
        # some hosts sanitize "." to "_"; accept the canonical id if that round-trips
        dotted = name.replace("_", ".")
        if dotted in self._name_map:
            return self._name_map[dotted]
        # A miss is not proof of absence: `skills.install`, `tools.enable` or a re-probe can
        # register a tool after the map was built, and a tool that this server lists but
        # refuses to call is worse than a slow lookup. Rebuild once, then decide.
        self.names()
        if name in self._name_map:
            return self._name_map[name]
        if dotted in self._name_map:
            return self._name_map[dotted]
        reg = self.toolkit.engine.registry
        near = reg.suggest(name) or reg.suggest(dotted)
        raise SkeletonKeyError(
            E.UNKNOWN_TOOL, f"unknown tool {name!r} on this server",
            details={"requested": name, "suggested": near,
                     "hint": "use tools/list; names are capability-gated"},
            next_actions=[{"tool": "registry.search", "args": {"query": dotted, "limit": 5}}]
            if not near else [{"tool": near[0]["id"], "note": "close match"}],
        )

    def advertise(self) -> Any:
        """The snapshot the client sees, at the registry's active tier.

        The full tier keeps the legacy `mcp.advertise_max_tools * 220` budget; the
        tiered path uses the `[advertise]` caps for that tier (0 = no cap), so
        `core` honestly stays a bootstrap surface instead of being silently
        re-budgeted by a legacy knob.
        """
        cfg = self.toolkit.config
        tier = self.engine.registry.active_tier
        if tier == "full":
            return self.engine.advertise(token_budget=cfg.mcp.advertise_max_tools * 220,
                                         dedupe_capability=True)
        return self.engine.advertise(tier=tier, tier_budgets=cfg.advertise.budgets(),
                                     dedupe_capability=True)


def build_server(toolkit: Any, *, include_resources: bool = True, include_prompts: bool = True) -> tuple:
    """Returns (server, init_options, bridge)."""
    from mcp.server.lowlevel import Server
    from mcp.server.models import InitializationOptions
    from mcp_types import (
        CallToolRequestParams,
        CallToolResult,
        GetPromptRequestParams,
        GetPromptResult,
        ListPromptsRequest,
        ListPromptsResult,
        ListResourcesRequest,
        ListResourcesResult,
        ListToolsResult,
        PaginatedRequestParams,
        Prompt,
        PromptMessage,
        ReadResourceRequestParams,
        ReadResourceResult,
        Resource,
        TextContent,
        TextResourceContents,
        ToolAnnotations,
        # NB: `Role` is Literal["user", "assistant"], not an enum - `role=Role.USER`
        # raises at call time, so the literal string is used below.
    )
    from mcp_types import (
        Tool as MTool,
    )

    bridge = McpBridge(toolkit)
    cfg = toolkit.config

    @asynccontextmanager
    async def lifespan(_server: Any):
        # `tools.hot_reload` is opt-in: a watch loop is a second reason for the tool set to
        # move under a running agent, and only the operator decides whether that is a feature.
        task = None
        if getattr(cfg.tools, "hot_reload", False):
            from ..skills.watch import watch_skills

            task = asyncio.create_task(watch_skills(toolkit, bridge))
        try:
            yield {"bridge": bridge, "toolkit": toolkit}
        finally:
            if task is not None:
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task

    server: Server = Server(SERVER_TITLE, version=__version__, instructions=INSTRUCTIONS,
                            lifespan=lifespan)

    # -------------------------------------------------------------------- tools
    async def on_list_tools(ctx: Any, params: Any) -> ListToolsResult:
        bridge.track_session(getattr(ctx, "session", None))
        snap = bridge.advertise()
        bridge._digest = snap.digest
        # mcp 2.1.1 lowlevel: for tools/list the params model is
        # PaginatedRequestParams (registered below), so `cursor` rides in as-is.
        cursor = (params.get("cursor") if isinstance(params, dict)
                  else getattr(params, "cursor", None))
        page, next_cursor = _page_slice(snap.tools, cursor)
        tools: list[MTool] = []
        for man in page:
            receipt = snap.receipt_for(man)
            desc = (man.description or "").strip()
            if man.anti_patterns:
                desc += "\nAvoid: " + "; ".join(man.anti_patterns[:2])
            if man.see_also:
                desc += "\nSee also: " + ", ".join(man.see_also[:3])
            ann = ToolAnnotations(
                title=man.title,
                readOnlyHint=man.risk in ("none", "read"),
                destructiveHint=bool(man.destructive),
                idempotentHint=bool(man.idempotent),
                openWorldHint=bool(man.open_world),
            )
            tools.append(MTool(
                name=man.id, title=man.title, description=desc[:1200],
                input_schema=man.input_schema_for_host(), annotations=ann,
                output_schema=man.output_schema,
                _meta={"sk": {"id": man.id, "risk": man.risk, "capability": man.capability,
                              "group": man.group, "tags": man.tags, "provider": man.provider,
                              "tier": man.tier, "reversible": man.reversible,
                              "stateful": man.stateful,
                              "typical_latency_ms": man.typical_latency_ms,
                              "requires": [r.to_dict() for r in man.requirements],
                              "provider_receipt": receipt}},
            ))
        return ListToolsResult(tools=tools, nextCursor=next_cursor, meta={
            "sk.digest": snap.digest, "sk.tokens_estimate": snap.tokens,
            "sk.tier": snap.tier, "sk.registered": len(bridge.engine.registry.all()),
            "sk.selected_providers": snap.selected,
            "sk.selection_receipts": snap.selection_receipts,
            "sk.budget_drops": snap.budget_drops})

    # tools that can scan a large tree: the client asks for progress by sending a
    # progressToken in the request's _meta, and the server answers with
    # notifications/progress while the scan runs (indeterminate: elapsed seconds,
    # no total - a tree walk's total is unknown until it finishes)
    PROGRESS_TOOLS = frozenset({"fs.search", "fs.glob"})

    async def _call_with_progress(tool_id: str, args: dict, token: Any, session: Any) -> Any:
        loop = asyncio.get_running_loop()
        start = time.monotonic()
        future = loop.run_in_executor(
            None, lambda: bridge.engine.call(tool_id, args, ctx=bridge.ctx,
                                             max_output_bytes=cfg.budget.max_output_bytes))
        if session is not None:
            # acknowledge immediately, then ping while the scan is alive: a host
            # rendering the turn sees "still working" without polling
            try:
                await session.send_progress_notification(token, 0)
            except Exception:                                     # pragma: no cover - defensive
                pass
            while not future.done():
                await asyncio.sleep(0.5)
                if session is not None and not future.done():
                    try:
                        await session.send_progress_notification(token, round(time.monotonic() - start, 1))
                    except Exception:                             # pragma: no cover - defensive
                        break
        return await future

    async def on_call_tool(ctx: Any, req: CallToolRequestParams) -> CallToolResult:
        args = dict(req.arguments or {})
        meta = getattr(req, "meta", None)
        extra = meta if isinstance(meta, dict) else (
            getattr(meta, "additional_properties", None) or getattr(meta, "model_extra", None)
            if meta is not None else None)
        progress_token = None
        if isinstance(extra, dict):
            if isinstance(extra.get("sk"), dict) and extra["sk"].get("task_id"):
                bridge.ctx.task_id = str(extra["sk"]["task_id"])
            progress_token = extra.get("progressToken", extra.get("progress_token"))
        try:
            tool_id = bridge.resolve_name(req.name)
        except SkeletonKeyError as exc:
            return _error_result(exc.err.to_dict(), req.name)

        session = getattr(ctx, "session", None)
        if session is not None:
            bridge.session = session
        if progress_token is not None and tool_id in PROGRESS_TOOLS and session is not None:
            res = await _call_with_progress(tool_id, args, progress_token, session)
        else:
            res = bridge.engine.call(tool_id, args, ctx=bridge.ctx,
                                     max_output_bytes=cfg.budget.max_output_bytes)
        payload = res.to_dict(max_bytes=cfg.budget.max_output_bytes, spill_dir=cfg.budget.spill_dir)
        text = compact_json(payload)
        structured = {k: v for k, v in payload.items() if k in ("ok", "data", "error", "hints",
                                                                "next_actions", "artifacts", "warnings",
                                                                "metrics", "context")}
        # APPROVAL_REQUIRED is returned as a coded envelope carrying the prompt
        # payload; real MCP elicitation (a protocol-level ask) is Phase 3.
        # A call can legitimately change what is advertised - `skills.install`, a profile
        # refresh, `tools.enable`. Push tools/list_changed on the session that made the call
        # instead of polling for a diff nobody asked about, and never let a closed session turn a
        # successful call into a failed one.
        if session is not None:
            try:
                await notify_tools_changed(bridge, session)
            except Exception:                                     # pragma: no cover - defensive
                pass
        # The host opted in with --log-level debug: stream this call's outcome as a
        # notifications/message log line for hosts that render it. Never let a logging
        # failure turn a successful call into a failed one.
        if session is not None and cfg.log_level.lower() == "debug":
            try:
                await session.send_log_message("debug", {
                    "tool": tool_id, "ok": res.ok, "ms": res.metrics.duration_ms,
                    "tokens": res.metrics.est_tokens,
                    "error_code": res.error.code if res.error else None,
                }, logger="skeletonkey")
            except Exception:                                     # pragma: no cover - defensive
                pass
        return CallToolResult(content=[TextContent(type="text", text=text)],
                              structuredContent=structured, isError=not res.ok)

    def _error_result(err: dict[str, Any], name: str) -> CallToolResult:
        payload = {"ok": False, "tool": name, "error": err}
        return CallToolResult(content=[TextContent(type="text", text=compact_json(payload))],
                              structuredContent=payload, isError=True)

    server.add_request_handler("tools/list", PaginatedRequestParams, on_list_tools)
    server.add_request_handler("tools/call", CallToolRequestParams, on_call_tool)

    # ------------------------------------------------------------------ prompts
    if include_prompts:
        async def on_list_prompts(_ctx: Any, _req: ListPromptsRequest) -> ListPromptsResult:
            prompts = [Prompt(name="capability_report", title="Capability report",
                              description="What this host can do and which tools are gated, as JSON.",
                              arguments=[]),
                       Prompt(name="task_bootstrap", title="Task bootstrap",
                              description="Skills matched to a task + the advertised tool set, ready to inject.",
                              arguments=[{"name": "task", "required": True,
                                           "description": "One or two sentences describing the job"}])]
            for skill in toolkit.skills.discover():
                prompts.append(Prompt(
                    name=f"skill_{skill.name.replace('-', '_')}", title=skill.name,
                    description=(skill.description or skill.when_to_use or f"skill {skill.name}")[:400],
                    arguments=[{"name": "task", "required": False,
                                "description": "Optional task text; used to pick reference files to inline"}]))
            return ListPromptsResult(prompts=prompts)

        async def on_get_prompt(_ctx: Any, req: GetPromptRequestParams) -> GetPromptResult:
            args = dict(req.arguments or {})
            if req.name == "capability_report":
                return GetPromptResult(description="host capabilities",
                                       messages=[PromptMessage(role="user", content=TextContent(
                                           type="text", text=compact_json(toolkit.describe())))])
            if req.name == "task_bootstrap":
                task = str(args.get("task", ""))
                payload = {"task": task, "skills": toolkit.skills.context_block(task),
                           "tools": [m.to_dict(include_schema=False) for m in bridge.advertise().tools],
                           "shells": {"available": toolkit.profile.available_dialects(),
                                      "preferred": toolkit.profile.preferred_dialect()}}
                return GetPromptResult(description="bootstrap context",
                                       messages=[PromptMessage(role="user", content=TextContent(
                                           type="text", text=compact_json(payload)))])
            skill_name = req.name.removeprefix("skill_").replace("_", "-")
            try:
                skill = toolkit.skills.get(skill_name)
            except SkeletonKeyError as exc:
                return GetPromptResult(description=f"unknown skill: {exc.err.message}", messages=[])
            refs: list[str] = []
            if args.get("task"):
                words = {w for w in str(args["task"]).lower().split() if len(w) > 3}
                refs = [r for r in skill.references if any(w in r.lower() for w in words)][:2]
            body = skill.render_injection(max_tokens=2000, with_references=refs)
            return GetPromptResult(description=skill.description or skill.name,
                                   messages=[PromptMessage(role="user",
                                                           content=TextContent(type="text", text=body))])

        server.add_request_handler("prompts/list", ListPromptsRequest, on_list_prompts)
        server.add_request_handler("prompts/get", GetPromptRequestParams, on_get_prompt)

    # ---------------------------------------------------------------- resources
    if include_resources:
        async def on_list_resources(_ctx: Any, _req: ListResourcesRequest) -> ListResourcesResult:
            items = [
                Resource(uri="skeletonkey://profile", name="Capability profile",
                         description="Host probes: OS, shells, binaries, filesystem traits, gates.",
                         mimeType="application/json"),
                Resource(uri="skeletonkey://tools", name="Advertised tools",
                         description="Current tool set with risk class and selected providers.",
                         mimeType="application/json"),
                Resource(uri="skeletonkey://viz/model", name="Toolset model",
                         description="Every REGISTERED tool as one document: gate receipts, "
                                     "withheld reasons, typed relations, token costs.",
                         mimeType="application/json"),
                Resource(uri="skeletonkey://journal", name="Change journal",
                         description="Recent journaled mutations with undo tokens.", mimeType="application/json"),
                Resource(uri="skeletonkey://ledger", name="Call ledger",
                         description="Tail of the append-only call ledger (hash-chained).",
                         mimeType="application/x-ndjson"),
            ]
            root = toolkit.config.workspace
            count = 0
            for dirpath, dirnames, filenames in os.walk(root):
                rel_dir = os.path.relpath(dirpath, root).replace(os.sep, "/")
                dirnames[:] = [d for d in dirnames if not d.startswith(".")
                               and not toolkit.sandbox.should_ignore(
                                   f"{rel_dir}/{d}" if rel_dir != "." else d)]
                if rel_dir.count("/") >= 2:
                    dirnames[:] = []
                for fn in filenames[:150]:
                    rel = os.path.relpath(os.path.join(dirpath, fn), root).replace(os.sep, "/")
                    if toolkit.sandbox.should_ignore(rel):
                        continue
                    items.append(Resource(uri=f"skeletonkey://file/{rel}", name=rel,
                                          mimeType="text/plain", description="workspace file"))
                    count += 1
                    if count > 300:
                        return ListResourcesResult(resources=items)
            return ListResourcesResult(resources=items)

        async def on_read_resource(_ctx: Any, req: ReadResourceRequestParams) -> ReadResourceResult:
            uri = str(req.uri)
            if uri == "skeletonkey://profile":
                text = compact_json(toolkit.profile.to_dict(include_receipts=False))
            elif uri == "skeletonkey://tools":
                text = compact_json([m.to_dict(include_schema=False) for m in bridge.advertise().tools])
            elif uri == "skeletonkey://viz/model":
                from skeletonkey.viz import build_viz_model

                model = build_viz_model(toolkit.engine.registry)
                doc = model.to_json()
                doc["model_digest"] = model.digest()
                text = compact_json(doc)
            elif uri == "skeletonkey://journal":
                text = compact_json(toolkit.journal.list(limit=100))
            elif uri == "skeletonkey://ledger":
                text = _tail_file(toolkit.ledger.path, 64_000) if toolkit.ledger else ""
            elif uri.startswith("skeletonkey://file/"):
                rel = uri.removeprefix("skeletonkey://file/")
                try:
                    text = toolkit.fs.read(rel, limit_lines=2000).content
                except SkeletonKeyError as exc:
                    from mcp_types import McpError

                    raise McpError(f"cannot read resource: {exc.err.code}: {exc.err.message}") from None
            else:
                from mcp_types import McpError

                raise McpError(f"unknown resource {uri}")
            return ReadResourceResult(contents=[TextResourceContents(uri=uri, mimeType="text/plain",
                                                                     text=text[:400_000])])

        server.add_request_handler("resources/list", ListResourcesRequest, on_list_resources)
        server.add_request_handler("resources/read", ReadResourceRequestParams, on_read_resource)

    # Advertise tools.listChanged: the tool set moves when the profile is re-probed
    # (a laptop plugs in, pwsh gets installed), and `notify_tools_changed` below sends
    # it. Claiming `false` would make spec-following hosts drop that notification.
    try:
        from mcp.server.lowlevel.server import NotificationOptions as _NotifOptions

        notif_options = _NotifOptions(tools_changed=True)
    except Exception:  # pragma: no cover - older/absent SDK shape
        notif_options = None

    init_options = InitializationOptions(
        server_name=SERVER_TITLE, server_version=__version__,
        capabilities=server.get_capabilities(
            notification_options=notif_options,
            experimental_capabilities={"skeletonkey": {"version": __version__, "dynamic_tools": True,
                                                        "profile_resource": "skeletonkey://profile"}}))
    return server, init_options, bridge


def _page_slice(tools: list[Any], cursor: str | None, page_size: int = 100) -> tuple[list[Any], str | None]:
    """Opaque positional cursor for tools/list (P5a pagination).

    A host that never sends a cursor gets the whole (small) surface in one page,
    exactly as before; the cursor is there for the 200-tool world.
    """
    start = 0
    if cursor:
        try:
            start = max(0, int(cursor))
        except ValueError:
            start = 0
    end = min(len(tools), start + page_size)
    return tools[start:end], (str(end) if end < len(tools) else None)


def _tail_file(path: str, nbytes: int) -> str:
    try:
        with open(path, "rb") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - nbytes))
            return fh.read().decode("utf-8", "replace")
    except OSError:
        return ""


async def notify_tools_changed(bridge: McpBridge, session: Any) -> bool:
    """Tell every connected client the advertisement moved.

    Returns True if at least one notification was delivered.

    Fan-out, not point-to-point: under streamable-http one bridge serves
    several clients, and a toolset change is not private to whoever caused it.
    The digest advances once for the whole fan-out, so a settled change costs
    exactly one notification per client no matter how many times this is
    called.

    A send failure means that client is gone; it is dropped rather than
    retried, and - importantly - it does not abort the fan-out to its peers.
    """
    if bridge._digest is None:
        return False        # no client has listed yet; a change notification would be noise
    snap = bridge.advertise()
    if snap.digest == bridge._digest:
        return False

    bridge.track_session(session)
    targets = list(bridge.sessions)
    if not targets:
        return False

    # Advance before sending: a client that reconnects mid-fanout will call
    # tools/list anyway, and re-entering here must not double-notify.
    bridge._digest = snap.digest

    delivered = 0
    for target in targets:
        try:
            await target.send_tool_list_changed()
            delivered += 1
        except Exception:
            bridge.drop_session(target)
    return delivered > 0


def make_approval_callback(*, auto: bool = False, echo: bool = True) -> Any:
    """Default approver for stdio hosts with no UI: deny-with-reason, never guess.

    `auto=True` (SKELETONKEY_AUTO_APPROVE=1) is the explicit autopilot dial.
    """
    def _approve(req: ApprovalRequired) -> bool:
        if auto:
            return True
        if echo:
            print(f"[skeletonkey] approval required: {req.tool} ({req.risk}) - {req.reason}",
                  flush=True)
        return False
    return _approve
