"""V2: serve the catalog, and notice when the toolset changes underneath it.

A static page (V1) is a photograph. This is the same page with a pulse: it
re-derives the model per request, and the browser polls a cheap digest route so
that installing a skill, reloading a module under HMR, or re-probing the host
shows up as a banner instead of silent drift.

Routes:

  GET /              the catalog page (V1's renderer, `live=True`)
  GET /api/model     the whole V0 model as JSON
  GET /api/digest    {model_digest, snapshot_digest, registered, advertised, at}
                     - the cheap poll; the page compares it to what it rendered
  GET /api/explain   V4 decision chains: why every tool is (not) advertised
  GET /api/runtime   V5 ledger overlay: measurements and contract drift
  GET /api/tool/<id> one node, plus its edges
  GET /healthz       {ok, uptime_s, requests}

Threading mirrors `live/panel.py`: `ThreadingHTTPServer` on a daemon thread,
`shutdown()` + `server_close()` + join on stop, so a test can start and stop
dozens of these without leaking a thread or a socket.

The server is **read-only**, and not merely by convention: there is no `do_POST`
at all, so a mutating route does not exist to be found. That is the V5 gate
(`--allow-calls`) pre-decided in the negative, which is the safe default for
something an operator might leave running.
"""

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from ..core.http_security import (
    HttpAccessPolicy,
    advertised_url,
    bind_url,
    bootstrap_cookie,
    inject_auth_bootstrap,
    token_fingerprint,
)
from .model import build_viz_model
from .render import render_html


class _ReusableHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True


class VizServer:
    """Serves one registry's toolset. Rebuilds the model per request.

    Rebuilding rather than caching is a deliberate cost: the model is a pure
    function of the registry and takes milliseconds, and a served page that can
    go stale is worse than no server at all.
    """

    def __init__(self, registry: Any, *, host: str = "127.0.0.1", port: int = 0,
                 title: str = "SkeletonKey toolset", tier: str | None = None,
                 read_only: bool = False, poll_ms: int = 2000,
                 ledger: Any = None, panel_url: str | None = None,
                 allow_remote: bool = False, auth_token: str = "",
                 allowed_origins: list[str] | tuple[str, ...] = (),
                 public_base_url: str = "",
                 access: HttpAccessPolicy | None = None) -> None:
        self.registry = registry
        self.ledger = ledger
        self.host = host
        self.public_base_url = public_base_url
        self.access = access or HttpAccessPolicy(
            host=host, allow_remote=bool(allow_remote), auth_token=auth_token,
            allowed_origins=tuple(allowed_origins), public_base_url=public_base_url)
        self.title = title
        self.tier = tier
        self.read_only = read_only
        self.poll_ms = int(poll_ms)
        # Cross-link only. The viz server never proxies to the panel and never
        # gains a write route by knowing about it: this is a string in a header
        # link, so the structural read-only guarantee (no do_POST) is untouched.
        self.panel_url = panel_url
        self.started_at = time.time()
        self.requests = 0
        self._lock = threading.Lock()
        self._requested_port = int(port)
        self._bound_port = int(port)
        self._server: _ReusableHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._make_server()

    def _make_server(self) -> None:
        self._server = _ReusableHTTPServer((self.host, self._requested_port), self._handler_class())
        self._server.daemon_threads = True
        self._bound_port = int(self._server.server_address[1])

    # ------------------------------------------------------------------ state
    @property
    def port(self) -> int:
        if self._server is not None:
            return int(self._server.server_address[1])
        return self._bound_port

    @property
    def advertised_url(self) -> str | None:
        return advertised_url(self.host, self.port, self.public_base_url)

    @property
    def url(self) -> str:
        return self.advertised_url or bind_url(self.host, self.port)

    def start(self) -> dict[str, Any]:
        if self._thread and self._thread.is_alive():
            return self.status()
        if self._server is None:
            self._make_server()
        assert self._server is not None
        self._thread = threading.Thread(target=self._server.serve_forever,
                                        name="sk-viz", daemon=True,
                                        kwargs={"poll_interval": 0.3})
        self._thread.start()
        return self.status()

    def stop(self) -> None:
        thread = self._thread
        if thread is None:
            if self._server is not None:
                self._server.server_close()
                self._server = None
            return
        assert self._server is not None
        self._server.shutdown()
        self._server.server_close()
        thread.join(timeout=3.0)
        self._thread = None
        self._server = None

    def __enter__(self) -> VizServer:
        self.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.stop()

    def status(self) -> dict[str, Any]:
        return {"serving": bool(self._thread and self._thread.is_alive()),
                "host": self.host, "port": self.port, "url": self.url,
                "advertised_url": self.advertised_url,
                "requests": self.requests,
                "panel_url": self.panel_url,
                "security": {"remote": self.access.remote,
                             "auth_required": self.access.requires_auth,
                             "token_fingerprint": token_fingerprint(self.access.auth_token),
                             "allowed_origins": list(self.access.allowed_origins),
                             "public_base_url": self.public_base_url or None},
                "uptime_s": round(time.time() - self.started_at, 1)}

    # ------------------------------------------------------------------ model
    def model(self) -> Any:
        # The registry is mutable from other threads (skill install, HMR): build
        # under a lock so two in-flight requests cannot interleave a rebuild.
        with self._lock:
            model = build_viz_model(self.registry, tier=self.tier,
                                    read_only=self.read_only)
        if self.ledger is not None:
            # Re-read per request like the model itself: the ledger grows while
            # the page is open, and a stale overlay is worse than none.
            from .runtime import attach_runtime

            attach_runtime(model, self.ledger)
        return model

    def digest_payload(self) -> dict[str, Any]:
        """The cheap poll. Still an honest full build - correctness over ceremony."""
        model = self.model()
        return {"model_digest": model.digest(),
                "snapshot_digest": model.snapshot["digest"],
                "registered": model.aggregates["registered"],
                "advertised": model.aggregates["advertised"],
                "tokens": model.snapshot["tokens"],
                "at": round(time.time(), 3)}

    def chains(self) -> dict[str, Any]:
        """V4 decision chains for every tool, for the drawer's why-not panel."""
        from .explain import explain_model

        with self._lock:
            return explain_model(self.registry, tier=self.tier,
                                 read_only=self.read_only)

    def tool_payload(self, tool_id: str) -> dict[str, Any] | None:
        model = self.model()
        node = model.node(tool_id)
        if node is None:
            return None
        return {"tool": node.to_json(),
                "edges": [e.to_json() for e in model.edges
                          if e.source == tool_id or e.target == tool_id]}

    # ----------------------------------------------------------------- server
    def _handler_class(self) -> type[BaseHTTPRequestHandler]:
        viz = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "SkeletonKeyViz/1"
            protocol_version = "HTTP/1.1"

            def log_message(self, fmt: str, *args: Any) -> None:   # quiet by design
                return

            def _send(self, status: int, body: bytes, ctype: str,
                      extra: dict[str, str] | None = None) -> None:
                viz.requests += 1
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                origin = str(self.headers.get("Origin") or "").strip()
                if origin and viz.access.origin_allowed(self.headers):
                    self.send_header("Access-Control-Allow-Origin", origin)
                    self.send_header("Vary", "Origin")
                cookie = bootstrap_cookie(
                    viz.access.token_from_request(self.headers, self.path),
                    secure=viz.public_base_url.lower().startswith("https://"))
                if cookie:
                    self.send_header("Set-Cookie", cookie)
                for key, value in (extra or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError, OSError):
                    pass

            def _json(self, status: int, obj: Any,
                      extra: dict[str, str] | None = None) -> None:
                data = json.dumps(obj, default=str).encode("utf-8", "replace")
                self._send(status, data, "application/json; charset=utf-8", extra)

            def _authorize(self) -> bool:
                refused = viz.access.check(self.headers, self.path)
                if refused is None:
                    return True
                status, message = refused
                extra = {"WWW-Authenticate": 'Bearer realm="skeletonkey-viz"'} \
                    if status == 401 else None
                self._json(status, {"error": message,
                                    "code": "AUTH_REQUIRED" if status == 401 else "ORIGIN_DENIED"},
                           extra=extra)
                self.close_connection = True
                return False

            def do_GET(self) -> None:
                from urllib.parse import unquote, urlparse

                if not self._authorize():
                    return
                route = urlparse(self.path).path
                route = route.rstrip("/") or "/"
                try:
                    if route == "/":
                        page = render_html(viz.model(), title=viz.title,
                                           live=True, poll_ms=viz.poll_ms,
                                           chains=viz.chains(),
                                           panel_url=viz.panel_url)
                        self._send(200, inject_auth_bootstrap(page).encode("utf-8"),
                                   "text/html; charset=utf-8")
                    elif route == "/api/model":
                        model = viz.model()
                        doc = model.to_json()
                        doc["model_digest"] = model.digest()
                        self._json(200, doc)
                    elif route == "/api/runtime":
                        self._json(200, viz.model().runtime or
                                   {"available": False, "drift": []})
                    elif route == "/api/explain":
                        self._json(200, {k: v.to_json()
                                         for k, v in viz.chains().items()})
                    elif route == "/api/digest":
                        self._json(200, viz.digest_payload())
                    elif route.startswith("/api/tool/"):
                        tool_id = unquote(route[len("/api/tool/"):])
                        payload = viz.tool_payload(tool_id)
                        if payload is None:
                            self._json(404, {"error": "no such tool", "id": tool_id})
                        else:
                            self._json(200, payload)
                    elif route == "/healthz":
                        self._json(200, {"ok": True, **viz.status()})
                    else:
                        self._json(404, {"error": "no such route", "path": route,
                                         "routes": ["/", "/api/model", "/api/digest",
                                                    "/api/explain", "/api/runtime",
                                                    "/api/tool/<id>", "/healthz"]})
                except Exception as exc:            # a broken page beats a dead server
                    self._json(500, {"error": type(exc).__name__, "message": str(exc)})

            def do_OPTIONS(self) -> None:
                # Preflight cannot carry the eventual Bearer header; enforce
                # origin here and authenticate the actual request.
                if not viz.access.origin_allowed(self.headers):
                    self._json(403, {"error": "request origin is not allowlisted",
                                     "code": "ORIGIN_DENIED"})
                    self.close_connection = True
                    return
                self._send(204, b"", "text/plain; charset=utf-8", {
                    "Allow": "GET, HEAD, OPTIONS",
                    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
                    "Access-Control-Allow-Headers": "Authorization, X-SkeletonKey-Token",
                    "Access-Control-Max-Age": "300",
                })

            def do_HEAD(self) -> None:
                self.do_GET()

        return Handler


def serve(registry: Any, *, host: str = "127.0.0.1", port: int = 0,
          **kwargs: Any) -> VizServer:
    """Start a VizServer and return it (already serving)."""
    server = VizServer(registry, host=host, port=port, **kwargs)
    server.start()
    return server
