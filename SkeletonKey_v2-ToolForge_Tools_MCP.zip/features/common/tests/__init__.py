# tests for features.common
